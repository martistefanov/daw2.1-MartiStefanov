<?php

    
    session_start();
     if(isset($_REQUEST["oculto"])){
        $_SESSION["oculto"] = $_REQUEST["oculto"];
    }

    if (!isset($_REQUEST["intento"])) { 
        $intento = null;

        $_SESSION['numIntentos'] = 0;
        
    } else { 
        $intento = $_REQUEST["intento"];

        $_SESSION['numIntentos'] = $_SESSION['numIntentos'] + 1;

        $numAsteriscos = 1 + log(abs($intento - $_SESSION["oculto"]), 1.5);
        $stringCercania = "";
        
        for ($i=1; $i <= $numAsteriscos; $i++) {
            $stringCercania = $stringCercania . "*";
            
        }
    }

?>



<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body>

<h1>ADIVINA EL NÚMERO</h1>


<?php

    if ($intento == null) {

    } elseif ($intento < $_SESSION["oculto"]) {
        echo "<p>El número que buscas es mayor ($stringCercania)</p>";
        
    } elseif ($intento > $_SESSION["oculto"]) {
        echo "<p>El número que buscas es menor ($stringCercania)</p>";
        
    } else {
        echo "<p>¡Has adivinado el número! Era, efectivamente " . $_SESSION["oculto"]; echo '.Has gastado '. $_SESSION['numIntentos']; echo' intentos.</p>';
        
    }



    if ($intento != $_SESSION["oculto"]) { 
?>

        <form method="post">
            <p>Jugador 2: Adivina el número (llevas <?= $_SESSION['numIntentos']; ?> intentos).</p> 
            <input type="number" name="intento">
            <input type="submit" value="Intentar">
        </form>

<?php
    }
?>

</body>

</html>