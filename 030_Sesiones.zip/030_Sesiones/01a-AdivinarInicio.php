<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body>

<h1>ADIVINAR EL NÚMERO</h1>

<form action="01b-AdivinarPrincipal.php" method="post">
    <p>Jugador 1: Introduce un número:</p>
    <input type="number" name="oculto" />
    <input type="submit" value="Guardar oculto" />
</form>

</body>

</html>