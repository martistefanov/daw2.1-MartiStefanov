<?php
    require_once "_Varios.php";

    borrarCookieRecordar();

    cerrarSesion();
    redireccionar("ContenidoPublico1.php");

?>
