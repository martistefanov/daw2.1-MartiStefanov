<?php

?>



<html>

<head>
    <meta charset='UTF-8'>
</head>



<body>

<h1>Iniciar Sesión</h1>


<!--
llamad a los campos IGUAL que en la BD:
identificador
contrasenna
-->

<form action="SesionInicioComprobar.php">

	<input type="text" name="identificador">
	<input type="text" name="contrasenna"> 
	<input type="submit">

</form>




</body>

</html>