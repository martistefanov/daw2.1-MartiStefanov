
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Base de datos: `agenda`
--
CREATE DATABASE IF NOT EXISTS `listaPerifericos` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `listaPerifericos`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

DROP TABLE IF EXISTS `tipo`;
CREATE TABLE IF NOT EXISTS `tipo` (
                                           `id` int(11) NOT NULL AUTO_INCREMENT,
                                           `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                                           PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipo`
--

INSERT INTO `tipo` (`id`, `nombre`) VALUES
(1, 'Monitor'),
(2, 'Ratón'),
(3, 'Teclado'),
(4, 'Auriculares'),
(5, 'Alfombrilla');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `periferico`
--

DROP TABLE IF EXISTS `periferico`;
CREATE TABLE IF NOT EXISTS `periferico` (
                                         `id` int(11) NOT NULL AUTO_INCREMENT,
                                         `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                                         `marca` varchar(45) DEFAULT NULL,
                                         `precio` varchar(15) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
                                         `estrella` tinyint(1) NOT NULL DEFAULT 0,
                                         `tipoId` int(11) NOT NULL,
                                         PRIMARY KEY (`id`),
                                         KEY `fk_tipoIdIdx` (`tipoId`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `periferico` (`id`, `nombre`, `marca`, `precio`, `estrella`, `tipoId`) VALUES
(1, 'Razer', 'Blackwidow', '120', 1, 3),
(2, 'Logitech', 'G502', '60', 1, 2),
(3, 'Asus', 'MG248Q', '320', 1, 1),
(4, 'HyperX', 'Cloud2', '100', 0, 4),
(5, 'BenQ', 'GW2780E', '170', 1, 1),
(6, 'NewSkill', 'NemesisV2', '30', 0, 5),
(7, 'HyperX', 'Revolver S', '100', 0, 4),
(8, 'Razer', 'Huntsman', '160', 0, 3),
(9, 'Razer', 'OrnataV2', '80', 0, 3),
(10, 'Razer', 'Kraken', '60', 0, 4),
(11, 'Razer', 'Goliathus', '20', 0, 5),
(12, 'NewSkill', 'Atami', '15', 0, 5),
(13, 'Logitech', 'G840', '50', 0, 5),
(14, 'NewSkill', 'Serike', '40', 0, 3),
(15, 'BenQ', 'SW240', '445', 0, 1),
(16, 'BenQ', 'ZOWIE', '390', 0, 1),
(17, 'Asus', 'VZ27VQ', '185', 0, 1),
(18, 'Asus', 'VP348QGL', '597', 0, 1),
(19, 'NewSkill', 'Eos', '35', 0, 2),
(20, 'Logitech', 'GPro', '82', 0, 2);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `periferico`
    ADD CONSTRAINT `fk_tipoId` FOREIGN KEY (`tipoId`) REFERENCES `tipo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;