<?php
    require_once "_Varios.php";

    $conexion = obtenerPdoConexionBD();

    $mostrarestrella = isset($_REQUEST["estrella"]);

    if(isset($_REQUEST["ordenacion"])){

         $orden = $_REQUEST["ordenacion"];

    }else{
       $orden = "defecto";
    }



    $posibleClausulaWhere = $mostrarestrella ? "WHERE p.estrella=1" : "";

if ($orden == "defecto") {
    $sql = "
               SELECT
                    p.id     AS pId,
                    p.nombre AS pNombre,
                    p.marca AS pMarca,
                    p.precio AS pPrecio,
                    p.estrella AS pEstrella,
                    t.id     AS tId,
                    t.nombre AS tNombre
                FROM
                   periferico AS p INNER JOIN tipo AS t
                   ON p.tipoId = t.id
                $posibleClausulaWhere
                ORDER BY p.nombre
            ";
}

if ($orden == "ordMarca") {
    $sql = "
               SELECT
                    p.id     AS pId,
                    p.nombre AS pNombre,
                    p.marca AS pMarca,
                    p.precio AS pPrecio,
                    p.estrella AS pEstrella,
                    t.id     AS tId,
                    t.nombre AS tNombre
                FROM
                   periferico AS p INNER JOIN tipo AS t
                   ON p.tipoId = t.id
                $posibleClausulaWhere
                ORDER BY p.marca
            ";
}


if ($orden == "ordTipo") {
    $sql = "
               SELECT
                    p.id     AS pId,
                    p.nombre AS pNombre,
                    p.marca AS pMarca,
                    p.precio AS pPrecio,
                    p.estrella AS pEstrella,
                    t.id     AS tId,
                    t.nombre AS tNombre
                FROM
                   periferico AS p INNER JOIN tipo AS t
                   ON p.tipoId = t.id
                $posibleClausulaWhere
                ORDER BY t.nombre
            ";
}




    $select = $conexion->prepare($sql);
    $select->execute([]); // Array vacío porque la consulta preparada no requiere parámetros.
    $rs = $select->fetchAll();


    // INTERFAZ:
    // $rs
    // $_SESSION
?>



<html>

<head>
    <meta charset='UTF-8'>
</head>



<body>

<h1>Listado de Perifericos</h1>

<label for="ordenacion">Ordenar por:</label>

<form action="PerifericoListado.php">
<select name="ordenacion">
  <option value="defecto">Marca</option>
  <option value="ordMarca">Modelo</option>
  <option value="ordTipo">Tipo</option>
</select>

<input type="submit" value="Actualizar">
</form>

<table border='1'>

    <tr>
        <th>Marca</th>
        <th>Modelo</th>
        <th>Precio</th>
        <th>Tipo</th>
    
    </tr>

    <?php
    foreach ($rs as $fila) { ?>
        <tr>
            <td>
                <?php
                    echo "<a href='PerifericoFicha.php?id=$fila[pId]'>";
                    echo "$fila[pNombre]";
                    if ($fila["pMarca"] != "") {
                        echo " $fila[pMarca]";
                    }

                    echo "</a>";

                    $urlImagen = $fila["pEstrella"] ? "img/carritoCompra.png" : "img/carritoCompraVacio.png";
                    echo " <a href='PerifericoEstablecerEstadoEstrella.php?id=$fila[pId]'><img src='$urlImagen' width='16' height='16'></a>";
                ?>
            </td>
            <td><a href= 'PerifericoFicha.php?id=<?=$fila["pId"]?>'> <?= $fila["pMarca"] ?> </a></td>
            <td><a href= 'PerifericoFicha.php?id=<?=$fila["pId"]?>'> <?= $fila["pPrecio"] ?> </a></td> 
            <td><a href= 'TipoFicha.php?id=<?=$fila["tId"]?>'> <?= $fila["tNombre"] ?> </a></td>
            <td><a href='PerifericoEliminar.php?id=<?=$fila["pId"]?>'> (X)                      </a></td>
        </tr>
    <?php } ?>

</table>

<br />


<?php if (!$mostrarestrella) {?>
    <a href='PerifericoListado.php?estrella'>Mostrar perifericos en el carrito</a>
<?php } else { ?>
    <a href='PerifericoListado.php'>Mostrar todos los perifericos</a>
<?php } ?>






<br />
<br />

<a href='PerifericoFicha.php?id=-1'>Crear entrada</a>

<br />
<br />

<a href='TipoListado.php'>Gestionar tipos</a>

<br>
<br>





</body>

</html>