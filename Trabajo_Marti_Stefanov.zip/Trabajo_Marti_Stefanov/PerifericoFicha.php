<?php
	require_once "_Varios.php";

	$conexion = obtenerPdoConexionBD();
	
	// Se recoge el parámetro "id" de la request.
	$id = (int)$_REQUEST["id"];

	// Si id es -1 quieren CREAR una nueva entrada ($nueva_entrada tomará true).
	// Sin embargo, si id NO es -1 quieren VER la ficha de una periferico existente
	// (y $nueva_entrada tomará false).
	$nuevaEntrada = ($id == -1);
	
	if ($nuevaEntrada) { // Quieren CREAR una nueva entrada, así que no se cargan datos.
		$perifericoNombre = "<introduzca nombre>";
        $perifericoMarca = "<introduzca Marca>";
		$perifericoPrecio = "<introduzca Precio>";
        $perifericoEstrella = false;
		$perifericotipoId = 0;
	} else { // Quieren VER la ficha de una periferico existente, cuyos datos se cargan.
        $sqlperiferico = "SELECT * FROM periferico WHERE id=?";

        $select = $conexion->prepare($sqlperiferico);
        $select->execute([$id]); // Se añade el parámetro a la consulta preparada.
        $rsperiferico = $select->fetchAll();

        // Con esto, accedemos a los datos de la primera (y esperemos que única) fila que haya venido.
		$perifericoNombre = $rsperiferico[0]["nombre"];
        $perifericoMarca = $rsperiferico[0]["marca"];
		$perifericoPrecio = $rsperiferico[0]["precio"];
        $perifericoEstrella = ($rsperiferico[0]["estrella"] == 1); // En BD está como TINYINT. 0=false, 1=true. Con esto convertimos a booolean.
		$perifericotipoId = $rsperiferico[0]["tipoId"];
	}

	
	
	// Con lo siguiente se deja preparado un recordset con todas las categorías.
	
	$sqltipos = "SELECT id, nombre FROM tipo ORDER BY nombre";

    $select = $conexion->prepare($sqltipos);
    $select->execute([]); // Array vacío porque la consulta preparada no requiere parámetros.
    $rstipos = $select->fetchAll();



    // INTERFAZ:
    // $perifericoNombre
    // $perifericoPrecio
    // $perifericoMarca
    // $perifericoEstrella
    // $perifericotipoId
    // $rstipos
?>




<html>

<head>
	<meta charset='UTF-8'>
</head>



<body>

<?php if ($nuevaEntrada) { ?>
	<h1>Nueva ficha de periferico</h1>
<?php } else { ?>
	<h1>Ficha de periferico</h1>
<?php } ?>

<form method='post' action='PerifericoGuardar.php'>

<input type='hidden' name='id' value='<?= $id ?>' />

    <label for='nombre'>Nombre</label>
    <input type='text' name='nombre' value='<?=$perifericoNombre ?>' />
    <br/>

    <label for='Marca'> Marca</label>
    <input type='text' name='marca' value='<?=$perifericoMarca ?>' />
    <br/>

    <label for='Precio'> Precio</label>
    <input type='text' name='precio' value='<?=$perifericoPrecio ?>' />
    <br/>

    <label for='tipoId'>Tipo</label>
    <select name='tipoId'>
        <?php
            foreach ($rstipos as $filatipo) {
                $tipoId = (int) $filatipo["id"];
                $tipoNombre = $filatipo["nombre"];

                if ($tipoId == $perifericotipoId) $seleccion = "selected='true'";
                else                                     $seleccion = "";

                echo "<option value='$tipoId' $seleccion>$tipoNombre</option>";

                // Alternativa (peor):
                // if ($tipoId == $perifericotipoId) echo "<option value='$tipoId' selected='true'>$tipoNombre</option>";
                // else                                     echo "<option value='$tipoId'                >$tipoNombre</option>";
            }
        ?>
    </select>
    <br/>

    <label for='estrella'>Estrellado</label>
    <input type='checkbox' name='estrella' <?= $perifericoEstrella ? "checked" : "" ?> />
    <br/>

    <br/>

<?php if ($nuevaEntrada) { ?>
	<input type='submit' name='crear' value='Crear periferico' />
<?php } else { ?>
	<input type='submit' name='guardar' value='Guardar cambios' />
<?php } ?>

</form>

<?php if (!$nuevaEntrada) { ?>
    <br />
    <a href='PerifericoEliminar.php?id=<?=$id ?>'>Eliminar periferico</a>
<?php } ?>

<br />
<br />

<a href='PerifericoListado.php'>Volver al listado de perifericos.</a>

</body>

</html>