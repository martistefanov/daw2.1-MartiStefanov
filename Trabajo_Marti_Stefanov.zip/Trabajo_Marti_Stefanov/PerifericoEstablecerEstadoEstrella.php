<?php
    require_once "_Varios.php";

    $conexion = obtenerPdoConexionBD();

    $id = $_REQUEST["id"];

    $sql = "UPDATE periferico SET estrella = (NOT (SELECT estrella FROM periferico WHERE id=?)) WHERE id=?";
    $sentencia = $conexion->prepare($sql);
    $sentencia->execute([$id, $id]);

    redireccionar("PerifericoListado.php");
?>