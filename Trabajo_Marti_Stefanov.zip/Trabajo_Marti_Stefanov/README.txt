La base de datos trata sobre una tienda de informatica la cual vende perifericos. 
La base de datos contiene una tabla de perifericos con atributos: Nombre, Modelo,Precio,
Marca... y otra tabla llamada 'Tipo' que indica si es un Auricular, Teclado, Monitor...

Tiene una tabla listado de perifericos donde podemos visualizar todos los perifericos y
ordenarlos gracias a un desplegable que ofrece, tambien podemos dar de alta nuevos 
perifericos, eliminarlos y actualizarlos, podemos guardarlos en la cesta de la compra
y visualizar solo los que hayamos guardado dandole al icono del carrito, por ultimo 
podremos ver los tipos de perifericos y ver que productos son del tipo Auriculares por
ejemplo o visualizar solo los Monitores...etc, y tambien se puede dar de alta,actualizar
y borrar.
