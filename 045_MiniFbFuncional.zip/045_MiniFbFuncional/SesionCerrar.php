<?php

    require_once "_com/_Varios.php";

    destruirSesionRamYCookie();

    redireccionar("Index.php");

?>
