<?php

    require_once "_com/_Varios.php";

?>



<html>

<head>
    <meta charset='UTF-8'>
</head>



<body>

<?php pintarInfoSesion(); ?>

<h1>MiniFb</h1>

<p>¡Bienvenido al MiniFb!</p>
<p>Esto es una red social en la que bla, bla, bla, bla.</p>
<p>Crea tu cuenta y participa.</p>

<a href='MuroVerGlobal.php'>Mira el muro global si ya tienes una cuenta.</a>

</body>

</html>